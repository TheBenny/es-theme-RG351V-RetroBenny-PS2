Original Warning by Jetup13 (I stand by it)
RG351V-Benny-PS5

Emulationstation theme almost entirely using videos
Supports screen sizes: RG351p/m/v, RK2020, RGB10, and OGA
Designed for TheRA and ArkOS
# Warning
Due to the theme using mostly videos it might your device might appear slow or warmer. 
Please keep this in mind. I would not recommend using this theme with continued usage. 
I'm not responsible for damage for your device. You've been warned
